import os
import time
import requests
import telegram
from threading import Thread

BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN")
CHAT_ID = os.getenv("TELEGRAM_CHAT_ID")  # شناسه چت خودت یا گروه
if not CHAT_ID:
    raise Exception("لطفا متغیر محیطی TELEGRAM_CHAT_ID را تنظیم کن")

bot = telegram.Bot(token=BOT_TOKEN)

BINANCE_API = "https://api.binance.com/api/v3/ticker/24hr"

# ذخیره حجم معاملات 24 ساعت گذشته در دیکشنری
previous_volumes = {}

# نسبت افزایش حجم که هشدار داده شود
VOLUME_THRESHOLD = 2.0

def fetch_volumes():
    try:
        response = requests.get(BINANCE_API)
        data = response.json()
        volumes = {}
        for coin in data:
            symbol = coin["symbol"]
            volume = float(coin["quoteVolume"])  # حجم به ارز پایه
            volumes[symbol] = volume
        return volumes
    except Exception as e:
        print("خطا در دریافت داده‌ها:", e)
        return {}

def check_volumes():
    global previous_volumes
    while True:
        current_volumes = fetch_volumes()
        if previous_volumes:
            for symbol, volume in current_volumes.items():
                prev_volume = previous_volumes.get(symbol, 0.0001)
                if prev_volume > 0 and volume / prev_volume >= VOLUME_THRESHOLD:
                    message = f"هشدار! حجم معاملات {symbol} ناگهان افزایش یافته است.
حجم قبلی: {prev_volume:.2f}
حجم فعلی: {volume:.2f}"
                    try:
                        bot.send_message(chat_id=CHAT_ID, text=message)
                    except Exception as e:
                        print("خطا در ارسال پیام تلگرام:", e)
        previous_volumes = current_volumes
        time.sleep(60)  # هر 60 ثانیه بررسی شود

if __name__ == "__main__":
    thread = Thread(target=check_volumes)
    thread.start()